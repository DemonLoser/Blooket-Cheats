# Citizen Code of Conduct

## 1. Purpose

A primary goal of Blooket Hacks is to be inclusive to the Ben Stewert website called blooket and alot of people love to cheat but they use bad hacks 
that do not work. But this hack works perfectly and effciently.





If you like the hacks please star the project
