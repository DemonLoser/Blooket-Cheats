# [Set Defense](https://github.com/hackthegamezjj/Blooket-Hacks/blob/main/Blook%20Rush/Set%20Defense.js)

## Adds Defense for you/team

# [Set Blooks](https://github.com/hackthegamezjj/Blooket-Hacks/blob/main/Blook%20Rush/Set%20blooks.js)

## Adds More Blooks for you/team
