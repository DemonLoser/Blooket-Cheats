# Crazy Kingdom Cheats

## [Choice ESP](ChoiceESP.js)
Choice ESP but it infinitely loops

## [Disable Toucan](disableToucan.js)
Never pay taxes

## [Max Stats](maxStats.js)
Sets all resources to the max

## [Set Guests](setGuests.js)
Sets the amount of guests you've seen

## [Skip Guest](skipGuests.js)
Skips the current guest
