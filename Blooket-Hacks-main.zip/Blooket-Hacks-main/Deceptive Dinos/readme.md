# Deceptive Dino Cheats

## [Auto Choose](autochoose.js)
Automatically choose the best fossil when excavating
## [Rock ESP](rockESP.js)
Shows what each rock will give you

## [Set Fossils](setfossils.js)
Sets the amount of fossils you have

## [Set Multiplier](setmultiplier.js)
Sets fossil multiplier

## [Stop Cheating](stopcheating.js)
Undoes cheating so that you can't be caught
