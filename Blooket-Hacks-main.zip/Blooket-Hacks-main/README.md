 # [New Hacks](https://github.com/hackthegamezjj/BLOOKET)


## Blooket-Hacks
The Best Blooket Hack There is

<details><summary><h3>How to run?</h3></summary>
simply select a hack folder and copy it then on your computer left click and click on inspect then go to console and paste the hack in then 
refresh your browser.
</details>





# [Tutorial](https://www.youtube.com/watch?v=0pJW6SOabk0)










<h3 align="left">Made With JavaScript:</h3>
<p align="left"> <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img
src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> </p>

Star the project or check out my other hacks 

Please star this project.
