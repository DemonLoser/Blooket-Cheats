# [Max Items](https://github.com/hackthegamezjj/Blooket-Hacks/blob/main/Cafe/maxitems.js)

## Gives you max items in cafe.

# [Remove Customers](https://github.com/hackthegamezjj/Blooket-Hacks/blob/main/Cafe/removecustomers.js)

## Skips the current customers

# [Set Cash](https://github.com/hackthegamezjj/Blooket-Hacks/blob/main/Cafe/setcash.js)

## Gives you cash

# [Reset Abilities](https://github.com/hackthegamezjj/Blooket-Hacks/blob/main/Cafe/resetAbilities.js)

## Resets the used abilities in the shop
